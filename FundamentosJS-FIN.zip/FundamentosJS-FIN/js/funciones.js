function sumar(numero1, numero2) {
    return numero1 + numero2
} 

function restar(numero1, numero2) {
    return numero1 - numero2
}

export {
    sumar,
    restar
}
