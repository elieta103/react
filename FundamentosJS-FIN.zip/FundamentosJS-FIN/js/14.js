// Funciones - Arrow Functions
const sumar = (numero, numero2) => numero + 20

const sumaArrow = () => 2 + 2

const resultado = sumaArrow()

console.log(resultado)

