// Destructuring de arrays
const tecnologias = ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js']

const [ , , , , var5] = tecnologias

console.log(var5)
