// Variables - const
const cliente = "Juan"
const precioDescuento = 220 

// No se puede re asignar
cliente = "Pablo"

// No pueden iniciar sin valor
// const precio



console.log(precio)
console.log(cliente)
console.log(precioDescuento)