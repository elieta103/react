// Variables - let 
let cliente = "Juan"
let precioDescuento = 220 // camelCase

// Re asignar
cliente = 20
cliente = true

// Pueden iniciar sin un valor
let precio

precio = 1000

console.log(precio)

console.log(cliente)
console.log(precioDescuento)