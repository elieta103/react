// Imports y Exports
import { sumar } from "./funciones.js"

const resultado = suma(20, 30)

console.log(resultado)