// Condicionales

const disponible = 4000
const retirar = 200

if( disponible > retirar ) {
    // Se cumpla la condición y se ejecuta el código
    console.log('Si puedes retirar')
} else {
    // no se cumple la condición, ejecutar este código
    console.log('Lo siento, no puedes retirar')
}

/**
 *  > - Mayor Que
 *  < - Menor que
 *  >=  Mayor o igual
 *  <= Menor o igual
 */