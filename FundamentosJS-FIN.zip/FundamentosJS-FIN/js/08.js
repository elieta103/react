// Arrays o Arreglos
const tecnologias = [20, 30, true, 'React', 'JavaScript']


console.log(tecnologias[10])
console.table(tecnologias)


console.log(tecnologias.length)
console.log(tecnologias.toString())